/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _BENCHMARK_H
#define _BENCHMARK_H

extern const unsigned int DEFAULT_BENCHMARK_ALGORITHMS_CNT;
extern const unsigned int DEFAULT_BENCHMARK_ALGORITHMS_BUF[];

#endif // _BENCHMARK_H
