/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _DISPATCH_H
#define _DISPATCH_H

void *thread_calc_stdin (void *p);
void *thread_calc (void *p);

#endif // _DISPATCH_H
