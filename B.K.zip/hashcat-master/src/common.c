/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#include "common.h"
